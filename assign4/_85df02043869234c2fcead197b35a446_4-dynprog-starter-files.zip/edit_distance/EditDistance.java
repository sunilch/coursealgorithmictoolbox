import java.util.*;

class EditDistance {
  public static int EditDistance(String s, String t) {
    //write your code here
    return 0;
  }
  public static void main(String args[]) {
    Scanner scan = new Scanner(System.in);

    String s = scan.next();
    String t = scan.next();

    System.out.println(EditDistance(s, t));
  }

}
